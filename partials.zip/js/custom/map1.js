//var base = "https://dhis2.jsi.com/dss";

   Ext.onReady(function() {

   DHIS.getMap({
  //"id": "qpSVp4QJ67Q", // with facilities
  "id": "qbPU8cuEEEN",   // Without facilities
  "el": "map1",
  //"url": "https://dhis2.jsi.com/dss"
  "url": "http://localhost:8080",
});

});